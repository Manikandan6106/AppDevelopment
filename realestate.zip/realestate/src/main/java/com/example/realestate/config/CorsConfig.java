package com.example.realestate.config;

public class CorsConfig {
    
}
