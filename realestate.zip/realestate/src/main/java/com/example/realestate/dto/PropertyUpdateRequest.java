package com.example.realestate.dto;

public class PropertyUpdateRequest {
    
}
